
<P align=center><FONT size=5 face=Arial><FONT size=3>Sales and Inventory 
Module<BR></FONT><FONT 
size=2>Foreign 
Trade Group Philippines</FONT></FONT></P>